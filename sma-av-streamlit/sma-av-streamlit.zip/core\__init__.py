"""Core package for SMA AV-AI Ops Streamlit app."""
