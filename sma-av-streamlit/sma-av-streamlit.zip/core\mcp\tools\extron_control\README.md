# Extron Control MCP Connector

Use this sample to bridge MCP actions to Extron control processors or Global Scripter endpoints.

Swap the stub functions in `connector.py` with calls to the Extron SIS or REST APIs for your hardware.
